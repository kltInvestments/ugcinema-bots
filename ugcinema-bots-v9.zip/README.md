UGCINEMA v9 placeholder — features A,B,C,D,E added.
