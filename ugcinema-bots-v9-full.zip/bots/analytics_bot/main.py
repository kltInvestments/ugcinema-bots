import asyncio
from telethon import events
from common.config import settings
from common.telegram_utils import make_client
from common import db

async def main():
    client = make_client("analytics_bot")
    await client.start(bot_token=settings.ANALYTICS_BOT_TOKEN)
    await db.init_pool(settings.DATABASE_URL)

    @client.on(events.NewMessage(chats=[settings.PAID_GROUP_ID]))
    async def on_message(event):
        try:
            user = await event.get_sender()
            uname = f"@{user.username}" if getattr(user, "username", None) else None
            await db.inc_engagement(user.id, uname)
        except Exception:
            pass

    print("Analytics bot running (engagement → Postgres).")
    await client.run_until_disconnected()

if __name__ == "__main__":
    asyncio.run(main())
