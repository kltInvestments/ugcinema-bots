import asyncio, re
from datetime import datetime, timedelta, timezone
from telethon import events, Button
from common.config import settings
from common.telegram_utils import make_client
from common import db

PRICE = settings.SUB_PRICE_UGX
DAYS = settings.SUB_DURATION_DAYS
ADMIN_ID = settings.ADMIN_ID
PAID_GROUP_ID = settings.PAID_GROUP_ID
PAYMENT_URL = settings.PAYMENT_URL

PENDING = {}  # user_id -> phone
BROADCAST_WAIT = set()  # admins awaiting next message for broadcast

UG_PHONE_RE = re.compile(r"^(\+256\d{9}|0?7\d{8}|7\d{8})$")
REMINDER_TEXT = "Tap the ‘I have paid ✅’ button below 😊"

def expiry_ts(days: int):
    return datetime.now(timezone.utc) + timedelta(days=days)

async def send_admin_summary(client):
    now = datetime.now(timezone.utc).date()
    lines = ["📋 **Upcoming Expirations (1-3 days)**"]
    try:
        recs = await db.fetch("SELECT telegram_id, username, expiry_date FROM subscriptions WHERE status='active'")
        for d in (1,2,3):
            due = now + timedelta(days=d)
            day_list = []
            for r in recs:
                exp = r["expiry_date"]
                if not exp: continue
                if exp.date() == due:
                    day_list.append(f"• {r['username'] or ''} ({r['telegram_id']}) on {exp.date()}")
            if day_list:
                lines.append(f"**In {d} day(s):**")
                lines.extend(day_list)
        if len(lines) > 1:
            await client.send_message(ADMIN_ID, "\n".join(lines))
    except Exception:
        pass

async def daily_task(client):
    while True:
        try:
            now = datetime.now(timezone.utc)
            recs = await db.fetch("SELECT id, telegram_id, status, expiry_date FROM subscriptions WHERE status='active'")
            for r in recs:
                uid = r["telegram_id"]; exp = r["expiry_date"]
                if not exp: continue
                days_left = (exp.date() - now.date()).days
                if days_left in (3,2,1):
                    try:
                        await client.send_message(uid, f"⏰ Your UGCINEMA Premium expires in {days_left} day(s). Renew to continue enjoying Full HD and new releases.")
                    except Exception: pass
                if days_left < 0:
                    try: await client.edit_permissions(PAID_GROUP_ID, uid, view_messages=False, send_messages=False)
                    except Exception: pass
                    await db.mark_expired(uid)
            await send_admin_summary(client)
        except Exception:
            pass
        await asyncio.sleep(24*60*60)

async def main():
    client = make_client("payment_bot")
    await client.start(bot_token=settings.PAYMENT_BOT_TOKEN)
    await db.init_pool(settings.DATABASE_URL)
    asyncio.create_task(daily_task(client))

    # ---------- help ----------
    @client.on(events.NewMessage(pattern="/help"))
    async def help_cmd(event):
        if event.sender_id == ADMIN_ID:
            await event.reply(
                "👑 **Admin Help**\n"
                "/subs – summary of subscribers\n"
                "/renew <telegram_id> – renew user\n"
                "/kick <telegram_id> – remove user\n"
                "/broadcast – send a message to the Premium group\n"
                "/categories – show latest titles per category\n"
                "/stats – analytics snapshot\n"
                "/premium – start premium flow"
            )
        else:
            await event.reply("🎬 **UGCINEMA Premium**\nUse /premium to subscribe.")

    # ---------- stats (A) ----------
    @client.on(events.NewMessage(pattern="/stats"))
    async def stats(event):
        if event.sender_id != ADMIN_ID: return await event.reply("Not authorized.")
        s = await db.stats_snapshot()
        lines = [
            f"👥 Active: {s['active']}",
            f"🪫 Expired: {s['expired']}",
            f"🎞️ Uploads: {s['uploads']}",
            "📚 By Category:"
        ]
        lines += [f"• {cat}: {cnt}" for cat, cnt in s["by_cat"]] or ["• (none)"]
        lines.append("🏆 Top Engagement:")
        if s["top_eng"]:
            for uname, uid, cnt in s["top_eng"]:
                lines.append(f"• {uname or uid}: {cnt}")
        else:
            lines.append("• (none)")
        await event.reply("\n".join(lines))

    # ---------- categories (B) ----------
    @client.on(events.NewMessage(pattern="/categories"))
    async def categories(event):
        from bots.uploader_bot.main import CATEGORIES  # reuse constant
        rows, row = [], []
        for i, name in enumerate(CATEGORIES, 1):
            row.append(Button.inline(name, data=f"catv:{name}".encode()))
            if i % 2 == 0: rows.append(row); row = []
        if row: rows.append(row)
        await event.reply("Choose a category:", buttons=rows)

    @client.on(events.CallbackQuery(pattern=b"catv:"))
    async def cat_view(event):
        cat = event.data.decode().split(":",1)[1]
        items = await db.recent_by_category(cat, limit=10)
        if not items:
            return await event.edit(f"**{cat}** — no items yet.")
        lines = [f"**{cat} — latest**"]
        for r in items:
            lines.append(f"• {r['title']}")
        await event.edit("\n".join(lines))

    # ---------- broadcast (E) ----------
    @client.on(events.NewMessage(pattern="/broadcast"))
    async def broadcast(event):
        if event.sender_id != ADMIN_ID: return await event.reply("Not authorized.")
        BROADCAST_WAIT.add(event.sender_id)
        await event.reply("Send the message you want to broadcast to the **Premium group**.")

    @client.on(events.NewMessage)
    async def maybe_broadcast_or_phone(event):
        # broadcast capture
        if event.sender_id in BROADCAST_WAIT and not event.raw_text.startswith("/"):
            BROADCAST_WAIT.remove(event.sender_id)
            await client.send_message(PAID_GROUP_ID, event.raw_text or "(empty message)")
            return await event.reply("✅ Broadcast sent to Premium group.")

        # phone / reminder for payments
        if event.sender_id in PENDING and event.raw_text:
            txt = event.raw_text.strip().replace(" ", "")
            if re.search(r"\bi\s*have\s*paid\b|\bpaid\b", txt, re.I):
                return await event.respond(REMINDER_TEXT)
            if UG_PHONE_RE.match(txt):
                PENDING[event.sender_id] = txt
                buttons = [[Button.inline("I have paid ✅", data=f"paid:{event.sender_id}".encode())]]
                return await event.respond("After paying, tap below to request approval.", buttons=buttons)

    # ---------- subs/renew/kick ----------
    @client.on(events.NewMessage(pattern="/subs"))
    async def subs(event):
        if event.sender_id != ADMIN_ID: return await event.reply("Not authorized.")
        active = await db.fetch("SELECT telegram_id, username, expiry_date FROM subscriptions WHERE status='active'")
        expired = await db.fetch("SELECT telegram_id FROM subscriptions WHERE status='expired'")
        now = datetime.now(timezone.utc).date()
        upcoming = []
        for r in active:
            if r["expiry_date"] and 0 <= (r["expiry_date"].date() - now).days <= 7:
                upcoming.append(f"• {r['username'] or ''} ({r['telegram_id']}) → {r['expiry_date'].date()}")
        msg = [f"👥 Active: {len(active)}", f"🪫 Expired: {len(expired)}", "🗓️ Upcoming (7d):" if upcoming else "🗓️ Upcoming (7d): none"]
        if upcoming: msg.extend(upcoming)
        await event.reply("\n".join(msg))

    @client.on(events.NewMessage(pattern=r"/renew (\d+)"))
    async def renew(event):
        if event.sender_id != ADMIN_ID: return await event.reply("Not authorized.")
        uid = int(event.pattern_match.group(1))
        start_ts = datetime.now(timezone.utc); exp_ts = start_ts + timedelta(days=DAYS)
        await db.upsert_subscription(uid, None, "", "active", start_ts, exp_ts)
        try: await client.edit_permissions(PAID_GROUP_ID, uid, view_messages=True, send_messages=True)
        except Exception: pass
        await event.reply(f"✅ Renewed {uid} until {exp_ts.date()}.")

    @client.on(events.NewMessage(pattern=r"/kick (\d+)"))
    async def kick(event):
        if event.sender_id != ADMIN_ID: return await event.reply("Not authorized.")
        uid = int(event.pattern_match.group(1))
        try: await client.edit_permissions(PAID_GROUP_ID, uid, view_messages=False, send_messages=False)
        except Exception: pass
        await db.mark_expired(uid); await event.reply(f"✅ Removed {uid} and marked expired.")

    # ---------- premium flow ----------
    @client.on(events.NewMessage(pattern="/premium"))
    async def premium(event):
        buttons = [[Button.inline(f"Join Premium — UGX {PRICE}", data=b"join")]]
        await event.respond(f"Join UGCINEMA Premium\nPrice: UGX {PRICE} / {DAYS} days\nBenefits: Full HD • Early Releases • No Ads", buttons=buttons)

    @client.on(events.CallbackQuery(data=b"join"))
    async def ask_phone(event):
        buttons = [[Button.url("Open Payment", url=PAYMENT_URL)]]
        await event.edit("Enter your **mobile number** used for payment (e.g., +25677xxxxxxx).\nThen tap **I have paid ✅**.", buttons=buttons)
        PENDING[event.sender_id] = ""

    @client.on(events.CallbackQuery(pattern=b"paid:"))
    async def notify_admin(event):
        _, uid_str = event.data.decode().split(":"); uid = int(uid_str)
        phone = PENDING.get(uid) or "(not provided)"
        sender = await event.get_sender()
        uname = f"@{sender.username}" if getattr(sender, "username", None) else "(no username)"
        approve_btn = Button.inline("✅ Approve", data=f"approve:{uid}".encode())
        deny_btn = Button.inline("❌ Deny", data=f"deny:{uid}".encode())
        await client.send_message(ADMIN_ID, f"Approve payment?\nUser ID: {uid}\nUser: {uname}\nPhone: {phone}", buttons=[[approve_btn, deny_btn]])
        await event.edit("Sent for admin verification.")

    @client.on(events.CallbackQuery(pattern=b"approve:"))
    async def approve(event):
        if event.sender_id != ADMIN_ID: return await event.answer("Not authorized.", alert=True)
        _, uid_str = event.data.decode().split(":"); uid = int(uid_str)
        phone = PENDING.get(uid) or ""
        start_ts = datetime.now(timezone.utc); exp_ts = start_ts + timedelta(days=DAYS)
        await db.upsert_subscription(uid, None, phone, "active", start_ts, exp_ts)
        try: await client.edit_permissions(PAID_GROUP_ID, uid, view_messages=True, send_messages=True)
        except Exception: pass
        # Welcome (C): DM + group note
        await client.send_message(uid, f"🎉 Welcome to UGCINEMA Premium! You are active for {DAYS} days.")
        await client.send_message(PAID_GROUP_ID, f"🎉 <a href='tg://user?id={uid}'>New Premium member</a> just joined. Welcome!", parse_mode="html")
        await event.edit("Approved and user activated.")
        PENDING.pop(uid, None)

    @client.on(events.CallbackQuery(pattern=b"deny:"))
    async def deny(event):
        if event.sender_id != ADMIN_ID: return await event.answer("Not authorized.", alert=True)
        _, uid_str = event.data.decode().split(":"); uid = int(uid_str)
        PENDING.pop(uid, None)
        await client.send_message(uid, "Payment not verified. Please try again or contact support.")
        await event.edit("Denied. User notified.")

    print("Payment bot running (v9: stats/categories/broadcast/welcome).")
    await client.run_until_disconnected()

if __name__ == "__main__":
    asyncio.run(main())
